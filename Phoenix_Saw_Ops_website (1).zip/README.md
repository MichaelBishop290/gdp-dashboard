# Phoenix Sawing Operations Dashboard

Run `npm i && npm run dev`.
